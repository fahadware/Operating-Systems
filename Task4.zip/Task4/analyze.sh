#!/bin/bash

echo "Script Name is: $0"

if [ $# -eq 0 ]; then
    echo "No arguments were provided.plz provide arguments.."
else
    
    echo "Total Number of Arguments: $#"

    
    echo "All Arguments: $@"

    
    if [ ! -z "$1" ]; then
        echo "First Argument: $1"
    fi
    if [ ! -z "$2" ]; then
        echo "Second Argument: $2"
    fi
fi

echo "Current User: $USER"
echo "Home Directory: $HOME"
echo "Present Working Directory: $PWD"

