#!/bin/bash

read -p "Enter the name of student: " name

# Ask for marks in three subjects
read -p "Enter marks for subject 1: " marks1
read -p "Enter marks for subject 2: " marks2
read -p "Enter marks for subject 3: " marks3

total=$((marks1+marks2+marks3))

average=$((total / 3))


if [ $average -ge 80 ]; 
then
    grade="A"
elif [ $average -ge 70 ]; 
then
    grade="B"
elif [ $average -ge 60 ]; 
then
    grade="C"
elif [ $average -ge 50 ]; 
then
    grade="D"
else
    grade="F"
fi



echo "Student Name is : $name"
echo "Total Marks are : $total"
echo "Average is : $average"
echo "Grade   is : $grade"


