#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
    int fd;
    char marks[5][10];
    int total = 0;
    int mark;
    int i;
    char buffer[50];


    fd = open("marks.txt", O_CREAT | O_WRONLY, S_IRUSR | S_IWUSR);    //O_CREAT will creates the file if it does not exist.....
    if (fd == -1) {
        perror("Error creating file");
        exit(1);
    }


    for (i = 0; i < 5; i++) {
        printf("Enter marks for subject %d: ", i + 1);
        scanf("%d", &mark);
        snprintf(marks[i], sizeof(marks[i]), "%d\n", mark);
        // Write the marks to the file
        if (write(fd, marks[i], sizeof(marks[i])) == -1) {
            perror("Error writing to file");
            close(fd);
            exit(1);
        }
    }

    close(fd);    //this willl close the file after wrting .........

    fd = open("marks.txt", O_RDONLY);    // now it will open the file for reading marks......
    if (fd == -1) {
        perror("Error opening file for reading");
        exit(1);
    }

    //read the marks from the file into the bufferr.......
    ssize_t bytesRead;
    int j = 0;
    while ((bytesRead = read(fd, buffer + j, 1)) > 0) {
        j++;-
    }
    buffer[j] = '\0';


    printf("\nMarks read from the file:\n");
    for (i = 0; i < 5; i++) {

        sscanf(&buffer[i * 3], "%d", &mark);  // this willl extract each mark from filee........
        total += mark;
        printf("Subject %d: %d\n", i + 1, mark);
    }

    printf("\nTotal Marks: %d\n", total);


    close(fd);

    return 0;
}
