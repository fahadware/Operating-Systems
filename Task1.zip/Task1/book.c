
#include <stdio.h>
#include <string.h>
#include "libraray.h"


void add_book(Book *book) {
    printf("Enter book ID: ");
    scanf("%d", &book->id);
    getchar();  // Consume newline character
    printf("Enter book name: ");
    fgets(book->name, sizeof(book->name), stdin);
    book->name[strcspn(book->name, "\n")] = '\0';  // Remove newline at the end
    printf("Book '%s' with ID %d has been added.\n", book->name, book->id);
}

