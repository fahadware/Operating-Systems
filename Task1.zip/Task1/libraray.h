
typedef struct {
    int id;
    char name[100];
} Book;

// Function prototypes.......
void add_book(Book *book);
void issue_book(int book_id, const char *student_name);

