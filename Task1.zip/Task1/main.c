#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "libraray.h"

#define MAX_BOOKS 100

int main() {
    Book books[MAX_BOOKS];
    int choice, book_count = 0;
    int book_id;
    char student_name[100];

    while (1) {
        printf("\nLibrary Management System\n");
        printf("1.Add Book\n");
        printf("2.Issue Book\n");
        printf("3.Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar();  
        
        switch (choice) {
            case 1:
                if (book_count < MAX_BOOKS) {
                    add_book(&books[book_count]);
                    book_count++;
                } else {
                    printf("Cannot add more books, library is full.\n");
                }
                break;
            case 2: 
                printf("Enter book ID to issue: ");
                scanf("%d", &book_id);
                getchar(); 
                printf("Enter student name: ");
                
                fgets(student_name, sizeof(student_name), stdin);
                student_name[strcspn(student_name, "\n")] = '\0'; 
                issue_book(book_id, student_name);
                break;
            case 3: 
                printf("Exiting system...\n");
                exit(0);
            default:
                printf("Invalid choice. Please input valid\n");
        }
    }

    return 0;
}

