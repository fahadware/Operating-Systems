#include <stdio.h>
#include <string.h>
#include "libraray.h"


void issue_book(int book_id, const char *student_name) {
    printf("Book with id %d has issued to %s.\n", book_id, student_name);
}

