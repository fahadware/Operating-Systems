#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
    int fd;
    int num1, num2, choice, result;

    fd = open("/tmp/myfifo", O_RDONLY);

    read(fd, &num1, sizeof(int));
    read(fd, &num2, sizeof(int));
    read(fd, &choice, sizeof(int));

    if(choice == 1)
        result = num1 + num2;
    else if(choice == 2)
        result = num1 * num2;
    else {
        printf("Invalid choice\n");
        return 1;
    }

    printf("Result: %d\n", result);

    close(fd);

    return 0;
}
