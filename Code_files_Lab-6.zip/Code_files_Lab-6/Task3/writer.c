#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
    int fd;
    int num1, num2, choice;

    fd = open("/tmp/myfifo", O_WRONLY);

    printf("Enter two numbers: ");
    scanf("%d %d", &num1, &num2);

    printf("Choose operation (1 = Sum, 2 = Product): ");
    scanf("%d", &choice);

    write(fd, &num1, sizeof(int));
    write(fd, &num2, sizeof(int));
    write(fd, &choice, sizeof(int));

    close(fd);

    return 0;
}
