#include <stdio.h>
#include <unistd.h>
#include <string.h>

int main() {

    int fd[2];
    pid_t pid;
    char write_msg[50]; 
    char read_msg[50];  

    pipe(fd); 

    pid = fork();

    if (pid > 0) {
        //parent process....
        close(fd[0]);  
        
        printf("Enter a string: ");
        scanf("%s", write_msg); 
        write(fd[1], write_msg, strlen(write_msg) + 1);
        close(fd[1]);
    } 
    else {
        // child process
        close(fd[1]);  
        read(fd[0], read_msg, sizeof(read_msg));
        
       
        int length = strlen(read_msg);
        printf("Reverse String is : ");
        for(int i = length - 1; i >= 0; i--) {
            printf("%c", read_msg[i]);
        }
        printf("\n");
        
        close(fd[0]);
    }

    return 0;
}
